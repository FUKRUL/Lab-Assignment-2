//
//  Item+CoreDataProperties.swift
//  A2_FA_iOS_Hasan_C0788314
//
//  Created by Hasan on 02/02/21.
//  Copyright © 2021 Hasan. All rights reserved.
//
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var itemId: Int32
    @NSManaged public var itemName: String?
    @NSManaged public var itemDescription: String?
    @NSManaged public var itemCost: Float
    @NSManaged public var itemProvider: String?

}
