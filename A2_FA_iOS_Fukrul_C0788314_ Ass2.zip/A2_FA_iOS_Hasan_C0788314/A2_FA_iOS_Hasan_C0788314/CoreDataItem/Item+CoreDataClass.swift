//
//  Item+CoreDataClass.swift
//  A2_FA_iOS_Hasan_C0788314
//
//  Created by Hasan on 02/02/21.
//  Copyright © 2021 Hasan. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}
